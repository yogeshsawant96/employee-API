var employeeModel = require('../models/user');
var multer = require('multer');

//typehead ngx bootstrap toaster 
//image upload 
var employees = {
    getAll: function (req, res) {


        employeeModel.find(function (err, docs) {
            if (err) {
                res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
            } else {

                res.send(docs);
                //res.status(200).json({ status: 'success', message: 'success', docs: docs });
            }
        });
    },

    getOne: function (req, res) {

        employeeModel.findById(req.params.id, function (err, doc) {
            if (err) {
                res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
            } else {
                res.send(doc);
                //res.status(200).json({ status: 'success', message: 'success', docs: doc });
            }
        });
    },
    create: function (req, res) {
        console.log(req.file);
        var employee = new employeeModel();
        employee.name = req.body.name;
        employee.email = req.body.email;
        employee.contact = req.body.contact;
        employee.gender = req.body.gender;
        employee.bloodGroup = req.body.bloodGroup;
        employee.designation = req.body.designation;

        employee.save(function (err) {
            if (err) {
                res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
            } else {

                res.status(200).json({ status: 'success', message: 'Document Added Successfully', docs: '' });
            }

        });
    },
    update: function (req, res) {

        employeeModel.findById(req.params.id, function (err, doc) {

            if (err)
                res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
                const url = req.protocol + "://" + req.get('host');
                doc.name = req.body.name;
                doc.email = req.body.email;
                doc.password = req.body.password;
                doc.gender = req.body.gender;
                doc.cities = req.body.cities;
                doc.DOB = req.body.DOB;
                doc.profilePic = url + "/" + req.file.filename;




            // save the doc
            doc.save(function (err) {
                if (err) {
                    res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
                } else {

                    res.status(200).json({ status: 'success', message: 'Document updated Successfully', docs: '' });
                }
            });

        });

    },
    delete: function (req, res) {
        employeeModel.remove({
            _id: req.params.id
        }, function (err, user) {
            if (err) {
                res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
            } else {

                res.status(200).json({ status: 'success', message: 'Document deleted Successfully', docs: '' });
            }
        });
    }
};

module.exports = employees;
