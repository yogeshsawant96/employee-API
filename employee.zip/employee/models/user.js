var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var user   = new Schema({
    name: String,
    email: String,
    contact: String,
    gender:String,
    bloodGroup:String,
    designation:String,
    profilePic:String
});

module.exports = mongoose.model('user', user);