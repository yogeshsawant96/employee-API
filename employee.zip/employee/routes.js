var express = require('express');
var router = express.Router();
// var products = require('./controllers/products.js');
var users = require('./controllers/users.js');
// var auth = require('./controllers/auth.js');
var multer = require('multer');
var userModel = require('./models/user');


// profile Pic storage ---------------------------------------------

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, new Date().toISOString() + file.originalname);
    }
});

const fileFilter = (req, file, cb) => {
    if (file.mimetype == 'image/jpeg' || file.mimetype == 'image/png') {
        cb(null, true);
    }
    else {
        cb(null, false);
    }
}

const upload = multer({
    storage: storage
});

// profile Pic storage ---------------------------------------------


//all routes
router.get('/employees/', users.getAll);
// router.post('/employee/', users.create);
router.get('/employee/:id', users.getOne);
router.delete('/employee/:id', users.delete);






// router.post('/login', auth);

router.post('/employee/', upload.single('profilePic'), (req, res) => {
    console.log(req.file);
    var user = new userModel();
    const url = req.protocol + "://" + req.get('host');
    user.name = req.body.name;
    user.email = req.body.email;
    user.contact = req.body.contact;
    user.gender = req.body.gender;
    user.bloodGroup = req.body.bloodGroup;
    user.designation = req.body.designation;
    user.profilePic = url + "/" + req.file.filename;


    user.save(function (err) {
        if (err) {
            res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
        } else {
            res.status(200).json({ status: 'success', message: 'Document Added Successfully', docs: '' });
        }
    });
});


router.put('/employee/:id', upload.single('profilePic'), (req, res) => {

    userModel.findById(req.params.id, function (err, doc) {
        const url = req.protocol + "://" + req.get('host');
        console.log(url);
        if (err)
            res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
        console.log(doc);
        // console.log(req.file);
        doc.name = req.body.name;
        doc.email = req.body.email;
        doc.contact = req.body.contact;
        doc.gender = req.body.gender;
        doc.bloodGroup = req.body.bloodGroup;
        doc.designation = req.body.designation;
        doc.profilePic = url + "/" + req.file.filename;


        // save the doc
        doc.save(function (err) {
            if (err) {
                res.status(500).json({ status: 'error', message: 'Database Error:' + err, docs: '' });
            } else {

                res.status(200).json({ status: 'success', message: 'Document updated Successfully', docs: '' });
            }
        });

    });

});

module.exports = router;

