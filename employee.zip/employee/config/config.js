var config = {

    port: 8080,
    site: 'http://localhost/nodeCRUD_Web/#/',

    
    mongo: {
        hostname: 'localhost',
        port: '27017',
        db: 'employeeCRUD'
        
    },
    
};
config.mongo.url= 'mongodb://' + config.mongo.hostname + ':' + config.mongo.port + '/' + config.mongo.db;


module.exports = config;